package com.example.entity;

public enum Genre {
MASCULIN,
FEMININ;
}
