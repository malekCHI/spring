package com.example.entity;

public enum Categorie {
	SPORT,
	ENFANT,
	ADULTE;

}
