package com.exemple.service;

import java.util.List;

import com.example.entity.Boutique;

public interface BoutiqueService {
	
	public void ajouterEtaffecterListeboutique(List<Boutique> lb, Long idCentre);
	List<Boutique> listedeBoutiques(Long idCentre);

}
