package com.exemple.service;

import java.util.List;


import com.example.entity.Client;

public interface ClientService {
	List<Client> listedeClients(Long idBoutique) ;
	public void ajouterEtAffecterClientBoutiques(Client client, List<Long> idBoutiques);
}
