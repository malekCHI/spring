package com.exemple.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Boutique;
import com.example.entity.CentreCommercial;
import com.example.entity.Client;
import com.exemple.repository.BoutiqueRepository;
import com.exemple.repository.CentreCommercialRepository;



@Service
public class BoutiqueServiceImpl implements BoutiqueService {

	@Autowired
	BoutiqueRepository br;
	
	@Autowired
	CentreCommercialRepository centreCommercialRepository;
	
	@Override
	public void ajouterEtaffecterListeboutique(List<Boutique> lb, Long idCentre) {
		// TODO Auto-generated method stub
		List<Boutique> bb = br.save(lb);
		CentreCommercial cc= centreCommercialRepository.findById(idCentre).orElse(null);
		cc.getBoutique().addAll(lb);
	}
	

	@Override
	public List<Boutique> listedeBoutiques(Long idCentre) {
		CentreCommercial b = centreCommercialRepository.findById(idCentre).orElse(null);
		return (List<Boutique>) b.getBoutique();
	}
}
