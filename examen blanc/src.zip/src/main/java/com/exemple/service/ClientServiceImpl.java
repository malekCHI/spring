package com.exemple.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Boutique;
import com.example.entity.CentreCommercial;
import com.example.entity.Client;
import com.exemple.repository.BoutiqueRepository;
import com.exemple.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService{
	
	
@Autowired
ClientRepository cr;
@Autowired
BoutiqueRepository br;

	@Override
	public List<Client> listedeClients(Long idBoutique) {
		Boutique b = br.findById(idBoutique).orElse(null);
		return (List<Client>) b.getClient();
	}
	
	
	@Override
	public void ajouterEtAffecterClientBoutiques(Client client, List<Long> idBoutiques) {
		// TODO Auto-generated method stub
		Client bb = cr.save(client);
		Boutique b= (Boutique) br.findAllById(idBoutiques);
		b.getClient().add(client);
	}

}
