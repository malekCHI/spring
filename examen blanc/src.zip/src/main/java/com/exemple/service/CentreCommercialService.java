package com.exemple.service;

import com.example.entity.CentreCommercial;

public interface CentreCommercialService {
	public void  ajouCentre(CentreCommercial centre);

}
