package com.exemple.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.CentreCommercial;
import com.exemple.repository.CentreCommercialRepository;

@Service
public class CentreCommercialServiceImpl implements CentreCommercialService {

	@Autowired
	CentreCommercialRepository ccr;
	
	@Override
	public void  ajouCentre(CentreCommercial centre) {
		ccr.save(centre);
		
	}
	
	
	
	
	
	
	
}
