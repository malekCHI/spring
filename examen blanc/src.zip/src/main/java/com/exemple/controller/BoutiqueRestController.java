package com.exemple.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Boutique;
import com.example.entity.Client;
import com.exemple.service.BoutiqueService;

@RestController
public class BoutiqueRestController {
@Autowired
BoutiqueService bs;
	
	@PostMapping("/ajouterEtaffecterListeboutique/{idProject}/{idCentre}") 
	@ResponseBody 
	public void ajouterEtaffecterListeboutique(@PathVariable("string")List<Boutique> lb,@PathVariable("idCentre") Long idCentre) {
    bs.ajouterEtaffecterListeboutique( lb , idCentre);
		
	}

	@GetMapping("/listedeBoutiques/{id}")
	@ResponseBody
	public List<Boutique> listedeBoutiques(@PathVariable("id")Long idCentre){
		List<Boutique> listP = bs.listedeBoutiques(idCentre);
		return listP;
	}
	
}
