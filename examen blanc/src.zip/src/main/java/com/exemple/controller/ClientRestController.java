package com.exemple.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Boutique;
import com.example.entity.Client;
import com.exemple.service.ClientService;

@RestController
public class ClientRestController {
	
	@Autowired
	ClientService cs;
	
	
	@GetMapping("/listedeClients/{id}")
	@ResponseBody
	public List<Client> listedeClients(@PathVariable("id")Long idBoutique){
		List<Client> listP = cs.listedeClients(idBoutique);
		return listP;
	}
	
	@PostMapping("/ajouterEtAffecterClientBoutiques/{idProject}/{idCentre}") 
	@ResponseBody 
	public void ajouterEtAffecterClientBoutiques(@PathVariable("string")Client client,@PathVariable("idCentre") List<Long> idBoutiques) {
    cs.ajouterEtAffecterClientBoutiques( client , idBoutiques);
		
	}

}
