package tn.esprit.spring.entities;

public enum Etat {
	STOPPED, RUNNING
}
